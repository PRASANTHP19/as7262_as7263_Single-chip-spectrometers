# Single_chip_spectrometer_AS7262_AS7263
This is a python library for sparkfun AS7262 and AS7263 sensors
With this library different properties of sensor can be controlled and data can 
be obtained.
please load varibles.py to folders set as python path for library to work properly
Library is still developing :)
(:Thanks to sparkfun for their Arduino Library which helped me lot in developing this:)
